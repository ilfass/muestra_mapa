<?php
/**
 * Plugin Name: Mapa de Convenios Internacionales v2
 * Description: Versión alternativa del mapa con mejoras experimentales. Usa el shortcode [mapa_convenios_v2 sheet="URL_DEL_GOOGLE_SHEET"]
 * Version: 2.0
 * Author: Fabián de Haro
 */

function mapa_convenios_v2_scripts() {
    if (!is_singular()) return;

    // Estilos
    wp_enqueue_style('leaflet-css-v2', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', [], null);
    wp_enqueue_style('mapa-style-v2', 'https://ilfass.github.io/muestra_mapa/css/styles.css', [], null);

    // Scripts
    wp_enqueue_script('leaflet-js-v2', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', [], null, true);
    wp_enqueue_script('helpers-js-v2', 'https://ilfass.github.io/muestra_mapa/js/helpers.js', ['leaflet-js-v2'], null, true);
    wp_enqueue_script('datos-v2-js', 'https://ilfass.github.io/muestra_mapa/js/datos-v2.js', ['helpers-js-v2'], null, true);
    wp_enqueue_script('mapa-v2-js', 'https://ilfass.github.io/muestra_mapa/js/mapa-v2.js', ['datos-v2-js'], null, true);
    wp_enqueue_script('main-v2-js', 'https://ilfass.github.io/muestra_mapa/js/main-v2.js', ['mapa-v2-js'], null, true);
}
add_action('wp_enqueue_scripts', 'mapa_convenios_v2_scripts');

function mapa_convenios_v2_shortcode($atts) {
    $atts = shortcode_atts([
        'sheet' => '',
    ], $atts);

    $output = '<div id="map-v2" class="mapa-convenios" style="width: 100%; height: 600px;"></div>';
    $output .= '<p id="mensaje-debug-v2">🧪 Mapa v2 cargado correctamente.</p>';

    if (!empty($atts['sheet'])) {
        $sheet_url = esc_url($atts['sheet']);
        $output = "<script>var googleSheetURL = '$sheet_url';</script>" . $output;
    }

    return $output;
}
add_shortcode('mapa_convenios_v2', 'mapa_convenios_v2_shortcode');
